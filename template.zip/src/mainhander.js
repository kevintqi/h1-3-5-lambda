class MainHandler {
  constructor() {
  }

  run(requestData) {
  }
}

module.exports = MainHandler;